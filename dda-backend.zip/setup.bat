@echo off
setlocal
CHCP 65001 >nul
title Thiết lập môi trường Python cho dự án dda-backend

echo ======================================================
echo Bắt đầu thiết lập môi trường Python cho dự án dda-backend...
echo ======================================================

:: 1. Kiểm tra Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Python chưa được cài đặt. Vui lòng cài Python trước.
    pause
    exit /b 1
)
echo [ok] Python đã được cài đặt.

:: 2. Tạo môi trường ảo
if not exist "venv" (
    echo Tạo môi trường ảo...
    python -m venv venv
) else (
    echo [!] Môi trường ảo đã tồn tại. Bỏ qua.
)

:: 3. Kích hoạt và nâng cấp pip
echo Kích hoạt môi trường ảo...
call venv\Scripts\activate.bat
python -m pip install --upgrade pip >nul

:: 4. Cài thư viện
if not exist "requirements.txt" (
    echo [!] Không tìm thấy requirements.txt.
    pause
    exit /b 1
) else (
    echo Cài đặt thư viện từ requirements.txt...
    pip install -r requirements.txt
    echo [ok] Thư viện đã được cài đặt.
)

:: 5. Kiểm tra Docker
docker --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Docker chưa được cài đặt. Vui lòng cài Docker Desktop trước.
    pause
    exit /b 1
)
echo [ok] Docker đã được cài đặt.

:: 6. Tạo container PostgreSQL nếu chưa có
docker ps -a --filter "name=dda-postgres" --format "{{.Names}}" | findstr "dda-postgres" >nul 2>&1
if %errorlevel% neq 0 (
    echo Tạo container PostgreSQL...
    docker run -d --name dda-postgres -e POSTGRES_USER=dda_user -e POSTGRES_PASSWORD=dda_pass -e POSTGRES_DB=dda_db -p 5432:5432 postgres:16
    echo [ok] Container dda-postgres đã được tạo.
) else (
    echo [!] Container dda-postgres đã tồn tại. Bỏ qua.
)

echo ======================================================
echo    THIẾT LẬP HOÀN TẤT!
echo ======================================================
pause